#This script calculates the binding and unbinding rates for LIO interacting with the position OP
#	This script requires:
#	
#	OP-Order-Param/*    Time series of the indicator function for LIO-OP for the 26 replicas.
#	/replica_index/*    Index of the temperatures for the replicas
#	/scripts/*	    Python scripts to analyse the indicator function. 
#       It additionally requires the folder: ../src/TREMD_kinetics/bin/kinetics/*
#

DIR="$(pwd)"
REP_T=${DIR}'/replica_index/'


index=0
max_num=(240000)


for ion in 'LIO' ;
do
	cd ${DIR}
	#KINETICS
	mkdir ${ion}
	mkdir ${ion}/kinetics
	for atom in 'OP'; do	
	cd ${ion}/kinetics/
		mkdir ${atom}/
		cp ${DIR}/scripts/analyze-kin-General.py  ${atom}/ 
	  	cp ${DIR}/scripts/eval-start.py ${atom}/
	  	cp ${DIR}/scripts/eval-lifetime.py ${atom}/
		cd ${atom}/
		mkdir RESULTS
		echo '####################################################'
		echo '######## Kinetics of '${ion} ${atom}'#################'
		echo '####################################################'
		pwd
      	        python analyze-kin-General.py  ${ion} ${atom} ${DIR}/OP-Order-Param  ${REP_T}/replica_index_${ion}.xvg ${max_num[${index}]}
   	        python eval-start.py ${ion}
                python eval-lifetime.py ${ion}
	done
	let "index= index+1"
done

